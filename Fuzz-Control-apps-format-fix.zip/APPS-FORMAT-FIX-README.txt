FUZZ APPS FORMAT FIX + RELEVANT APPS
======================================

WHAT THIS FIXES
---------------
- Removes the blank loading-card rows that stayed visible after apps loaded.
- Makes the app library use more of wide and 4K screens.
- Increases card size, text size, spacing, and icon clarity.
- Adds a recommended apps section.
- Adds app descriptions and clearer category labels.
- Adds School, Productivity, Coding, and Music filters.

NEW APPS
--------
Adds a curated group of school, productivity, design, media, social, and cloud-gaming apps including Google Workspace apps, Quizlet, Khan Academy, Desmos, WolframAlpha, Notion, Microsoft 365, Teams, Zoom, Replit, CodePen, Photopea, Figma, Reddit, Netflix, Disney+, Hulu, Prime Video, Roblox, Xbox Cloud Gaming, and Epic Games Store.

INSTALL
-------
1. Back up the current project.
2. Upload this ZIP beside index.js.
3. Run: unzip -o Fuzz-Control-apps-format-fix.zip
4. Restart with: npm start
5. Open /b and hard-refresh with Ctrl + Shift + R.

No Supabase SQL changes are required.
