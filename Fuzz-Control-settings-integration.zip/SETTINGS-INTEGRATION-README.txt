FUZZ SETTINGS + ACCOUNT CENTER INTEGRATION
==========================================

WHAT CHANGED
------------
- The normal navbar Settings tab now opens /account#preferences.
- /c and /settings.html automatically redirect to the Account Center settings page.
- Account-synced preferences and browser-only settings now live together.
- No Admin Panel link or icon was added to the normal website.

INTEGRATED SETTINGS
-------------------
Account synced:
- Appearance
- Default search engine
- Fuzz AI response style
- Announcements
- Reduced motion
- Detailed proxy-history retention

Browser only:
- About:blank startup option
- Panic keys and panic link
- About:blank window launcher
- Tab cloak preset
- Background image
- Ultraviolet/Dynamic proxy mode
- Particles
- Browser-settings export/import

INSTALL
-------
1. Back up your current files:
   git add .
   git commit -m "Backup before settings integration"

2. Upload this ZIP beside index.js and extract it:
   unzip -o Fuzz-Control-settings-integration.zip

3. Check the JavaScript:
   node --check static/assets/js/account.js
   node --check static/assets/js/m1.js

4. Restart:
   npm start

5. Open the normal website, click Settings, and hard-refresh:
   Ctrl + Shift + R

NO DATABASE OR SUPABASE SQL CHANGES ARE REQUIRED.
