-- FuzzTheHuzz 5.3.0 Mega Update
-- Synced bookmarks with Row Level Security.

create table if not exists public.user_bookmarks (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  title text not null check (char_length(title) between 1 and 160),
  url text not null check (char_length(url) between 1 and 4000),
  engine text not null default 'scramjet'
    check (engine in ('scramjet', 'ultraviolet')),
  pinned boolean not null default false,
  position integer not null default 0
    check (position between 0 and 100000),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (user_id, url)
);

create index if not exists user_bookmarks_user_sort_idx
  on public.user_bookmarks (user_id, pinned desc, position asc, updated_at desc);

alter table public.user_bookmarks enable row level security;

revoke all on public.user_bookmarks from anon;
grant select, insert, update, delete on public.user_bookmarks to authenticated;

-- Recreate policies safely when the migration is run more than once.
drop policy if exists "Users can read their own bookmarks" on public.user_bookmarks;
drop policy if exists "Users can create their own bookmarks" on public.user_bookmarks;
drop policy if exists "Users can update their own bookmarks" on public.user_bookmarks;
drop policy if exists "Users can delete their own bookmarks" on public.user_bookmarks;

create policy "Users can read their own bookmarks"
  on public.user_bookmarks
  for select
  to authenticated
  using (auth.uid() = user_id);

create policy "Users can create their own bookmarks"
  on public.user_bookmarks
  for insert
  to authenticated
  with check (auth.uid() = user_id);

create policy "Users can update their own bookmarks"
  on public.user_bookmarks
  for update
  to authenticated
  using (auth.uid() = user_id)
  with check (auth.uid() = user_id);

create policy "Users can delete their own bookmarks"
  on public.user_bookmarks
  for delete
  to authenticated
  using (auth.uid() = user_id);

-- Read-only RLS audit: this returns exposed public tables where RLS is disabled.
select
  schemaname,
  tablename,
  rowsecurity
from pg_tables
where schemaname = 'public'
  and rowsecurity = false
order by tablename;
