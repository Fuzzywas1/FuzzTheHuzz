FUZZTHEHUZZ 5.3.0 — MEGA UPDATE
===============================

This update combines the requested browsing, reliability, organization,
onboarding, customization, update, and security improvements. InvisiProxy is
not included; Scramjet remains the primary engine with Ultraviolet fallback.

MAIN FEATURES
-------------
- Home search first, with Scramjet/Ultraviolet cards directly underneath.
- Matching proxy selector on every New Tab page.
- Scramjet remains the recommended default.
- One-click Ultraviolet retry when Scramjet fails.
- Synced bookmarks with automatic local-browser fallback.
- Pinned bookmarks and recently visited sites on Home.
- Bookmarks, recent sites, and recently closed tabs in Tabs.
- Bookmark import/export.
- Reopen recently closed tab with Ctrl+Shift+T.
- New authenticated /status diagnostics page.
- Owner System Health page inside Fuzz Control.
- Searchable client error IDs logged in Activity.
- First-run onboarding wizard.
- Accent colors, compact spacing, motion, backgrounds, shortcuts, and update notices.
- Version 5.3.0 update banner and changelog.
- Defensive CSP, permissions policy, referrer policy, and nosniff headers on normal pages.
- Copyable diagnostics, browser-side Wisp testing, and direct links to Status.
- Session recovery, drag-to-reorder tabs, fullscreen, compact Tabs, and popout.
- Proxy runtime pages remain exempt from restrictive headers so Scramjet and UV keep working.

INSTALL
-------
1. Back up the current project:

   git add .
   git commit -m "Backup before Fuzz 5.3.0 mega update"

2. Upload Fuzz-Control-Mega-Update.zip beside index.js and extract it:

   unzip -o Fuzz-Control-Mega-Update.zip

3. In Supabase > SQL Editor, run:

   database-mega-update.sql

   The final SELECT is a read-only RLS audit. Review any returned tables before
   changing their policies. The update itself only creates and secures the new
   user_bookmarks table.

4. Check the changed JavaScript:

   node --check index.js
   node --check static/assets/js/t3.js
   node --check static/assets/js/tabs-plus.js
   node --check static/assets/js/fuzz-ui.js
   node --check static/assets/js/fuzz-browser-data.js
   node --check static/assets/js/fuzz-diagnostics.js
   node --check static/assets/js/status.js
   node --check static/assets/js/account.js
   node --check static/assets/js/admin/health.js
   node --check static/assets/js/admin/router.js
   node --check static/assets/js/admin/api.js

5. Restart:

   npm start

6. Clear old cached workers once:

   DevTools > Application > Service Workers > Unregister
   DevTools > Application > Storage > Clear site data

   Then close every Fuzz tab, reopen the site, and press Ctrl+Shift+R.

TEST CHECKLIST
--------------
- Complete the onboarding screen on Home.
- Search example.com using Scramjet.
- Switch to Ultraviolet and test example.com again.
- Save a bookmark with the star button.
- Confirm it appears in the Tabs library and on Home.
- Close a website tab and press Ctrl+Shift+T.
- Open /status and run the checks.
- Open Admin > System Health and confirm the checks load.
- Open My Account > Preferences and test accent/density settings.

DATABASE FALLBACK
-----------------
The browser remains usable before database-mega-update.sql is run. Bookmarks
will be stored in localStorage on that browser. After the table is installed,
new bookmark operations sync to the signed-in account.

ROLLBACK
--------
Restore the backup commit:

   git reset --hard HEAD~1

The user_bookmarks table can remain safely in Supabase, or be removed manually
later after exporting any bookmarks.
