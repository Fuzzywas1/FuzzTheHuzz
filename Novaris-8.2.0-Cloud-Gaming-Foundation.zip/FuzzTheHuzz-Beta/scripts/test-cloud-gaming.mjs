import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import { after, test } from "node:test";
import vm from "node:vm";
import express from "express";
import { createCloudGamingStore, registerCloudGaming } from "../lib/cloud-gaming.js";

const userId = "00000000-0000-4000-8000-000000000001";
const missingId = "00000000-0000-4000-8000-000000000002";
const permissions = new Map();
const logs = [];
let databaseDown = false;
const source = fs.readFileSync(new URL("../index.js", import.meta.url), "utf8");
// Exercise the existing production page/API/role middleware, replacing only
// the external Supabase identity lookup and suspension response dependency.
const context = vm.createContext({
  console,
  getAuthenticatedUser: async req => {
    const role = req.get("x-test-role");
    if (!role || req.get("x-test-banned")) return null;
    return { user: { id: userId }, profile: { role, username: "tester" }, suspension: { active: req.get("x-test-suspended") === "true" } };
  },
  clearAuthCookies() {},
  sendSuspensionResponse: res => res.status(403).json({ error: "Suspended" }),
});
vm.runInContext(source.slice(source.indexOf("async function requirePageAuth("), source.indexOf("function getRequestHeader(")), context);
const gates = vm.runInContext("({ requirePageAuth, requireApiAuth, requireRole })", context);
const app = express();
app.use(express.json());
registerCloudGaming(app, {
  ...gates,
  store: {
    async allowed(id) {
      if (databaseDown) throw new Error("offline");
      return permissions.get(id) === true;
    },
    async list() {
      if (databaseDown) throw new Error("offline");
      return Object.fromEntries(permissions);
    },
    async set(id, enabled) {
      if (databaseDown) throw new Error("offline");
      if (id !== userId) return false;
      permissions.set(id, enabled);
      return true;
    },
  },
  pagePath: path.resolve("views/cloud-games.html"),
  writeActivityLog: entry => logs.push(entry),
});
app.use(express.static(path.resolve("static"), { index: false }));
const server = app.listen(0, "127.0.0.1");
await new Promise(resolve => server.once("listening", resolve));
after(() => new Promise(resolve => server.close(resolve)));
const origin = `http://127.0.0.1:${server.address().port}`;
const request = (url, role, options = {}) =>
  fetch(origin + url, {
    redirect: "manual",
    ...options,
    headers: { ...(role ? { "x-test-role": role } : {}), ...options.headers },
  });
const toggle = (role, enabled, id = userId) =>
  request(`/api/admin/users/${id}/cloud-gaming`, role, {
    method: "PATCH",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ enabled }),
  });

test("Cloud Gaming authorization, admin updates, revocation and unavailable sessions", async () => {
  for (const route of ["/cloud-games", "/cloud-games.html", "/cloud-games/"]) {
    assert.equal((await request(route)).status, 302);
    for (const role of ["user", "moderator", "admin", "owner"]) {
      assert.equal((await request(route, role)).status, 403, `${role} must explicitly receive permission`);
    }
  }
  assert.equal((await request("/api/cloud-games")).status, 401);
  for (const role of [undefined, "user", "moderator"]) {
    assert.equal((await toggle(role, true)).status, role ? 403 : 401);
    assert.equal((await request("/api/admin/cloud-gaming/permissions", role)).status, role ? 403 : 401);
  }
  for (const value of ["true", 1, null, undefined, {}]) assert.equal((await toggle("admin", value)).status, 400);
  assert.equal((await toggle("admin", true, "bad-id")).status, 400);
  assert.equal((await toggle("admin", true, missingId)).status, 404);
  assert.equal((await toggle("admin", true)).status, 200);
  assert.equal(logs[0].metadata.enabled, true);
  assert.equal((await (await request("/api/admin/cloud-gaming/permissions", "owner")).json()).permissions[userId], true);
  for (const route of ["/cloud-games", "/cloud-games.html", "/CLOUD-GAMES", "/cloud-games/"]) {
    const response = await request(route, "user");
    assert.equal(response.status, 200);
    assert.match(response.headers.get("cache-control"), /no-store/);
    const html = await response.text();
    assert.match(html, /<title[^>]*>Home<\/title>/);
    assert.match(html, /Roblox/);
    assert.doesNotMatch(html, /novnc|iframe|cloud\.js/i);
  }
  assert.equal((await request("/cloud-games", "user", { method: "HEAD" })).status, 200);
  const catalog = await (await request("/api/cloud-games", "user")).json();
  assert.equal(catalog.games[0].launchable, false);
  const launch = await request("/api/cloud-games/sessions", "user", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ gameId: "roblox", userId: missingId }),
  });
  assert.equal(launch.status, 503);
  assert.equal((await launch.json()).code, "STREAMING_NOT_CONFIGURED");
  assert.equal(
    (
      await request("/api/cloud-games/sessions", "user", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ gameId: "unknown" }),
      })
    ).status,
    400,
  );
  for (const header of ["x-test-suspended", "x-test-banned"]) {
    const response = await request("/api/cloud-games", "user", { headers: { [header]: "true" } });
    assert.equal(response.status, header === "x-test-suspended" ? 403 : 401);
    assert.equal((await request("/cloud-games", "user", { headers: { [header]: "true" } })).status, 302);
  }
  databaseDown = true;
  assert.equal((await request("/cloud-games", "user")).status, 503);
  assert.equal((await request("/api/cloud-games", "user")).status, 503);
  assert.equal((await toggle("admin", false)).status, 503);
  databaseDown = false;
  assert.equal((await toggle("owner", false)).status, 200);
  for (const route of ["/cloud-games", "/cloud-games.html", "/CLOUD-GAMES", "/cloud-games/", "/cloud-games.html/", "/api/cloud-games"]) {
    assert.equal((await request(route, "user")).status, 403);
  }
  assert.equal((await request("/cloud-games", "user", { method: "HEAD" })).status, 403);
  assert.equal((await request("/api/cloud-games/sessions", "user", { method: "POST" })).status, 403);
  for (const route of ["/cloud%2dgames.html", "/views/cloud-games.html", "/static/cloud-games.html", "/%63loud-games.html"]) {
    assert.equal((await request(route, "user")).status, 404, `No static bypass: ${route}`);
  }
});

test("permission store defaults OFF, rejects truthy data and propagates database errors", async () => {
  let result = { data: null, error: null };
  const db = { from: () => ({ select: () => ({ eq: () => ({ maybeSingle: async () => result }) }) }) };
  const store = createCloudGamingStore(db);
  assert.equal(await store.allowed(null), false);
  assert.equal(await store.allowed(userId), false);
  result = { data: { enabled: "true" } };
  assert.equal(await store.allowed(userId), false);
  result = { data: { enabled: true } };
  assert.equal(await store.allowed(userId), true);
  result = { error: new Error("database unavailable") };
  await assert.rejects(store.allowed(userId), /database unavailable/);
});

test("navigation is fail-closed and the permission table has no browser grants", () => {
  const nav = fs.readFileSync("static/assets/js/m1.js", "utf8");
  const start = nav.indexOf("  function isRouteVisible(");
  const end = nav.indexOf("  function renderShell(", start);
  for (const value of [undefined, false, "true", true]) {
    const visible = vm.runInNewContext(`${nav.slice(start, end)}; isRouteVisible({feature: 'cloudGaming'})`, { platformConfig: { cloudGaming: { allowed: value } } });
    assert.equal(visible, value === true);
  }
  const sql = fs.readFileSync("supabase/NOVARIS_CLOUD_GAMING_SCHEMA.sql", "utf8");
  assert.match(sql, /enable row level security/);
  assert.match(sql, /revoke all[^;]+from public, anon, authenticated/);
  assert.match(sql, /default false/);
  assert.equal(fs.existsSync("static/cloud-games.html"), false);
  assert.ok(source.indexOf("registerCloudGaming(app,") < source.indexOf('path.join(__dirname, "static"),'));
});
