create table if not exists public.account_app_state (
  user_id uuid primary key references public.profiles(id) on delete cascade,
  favorites jsonb not null default '[]'::jsonb,
  recent jsonb not null default '[]'::jsonb,
  open_counts jsonb not null default '{}'::jsonb,
  custom_apps jsonb not null default '[]'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.account_app_state enable row level security;

comment on table public.account_app_state is
  'Private account-synced favorites, recents, usage counts, and custom shortcuts for the Fuzz Apps library.';
