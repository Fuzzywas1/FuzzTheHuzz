FUZZ APPS LIBRARY UPGRADE
=========================

WHAT THIS UPDATE ADDS
---------------------
- Complete Apps page redesign matching the refreshed homepage
- Instant search with / keyboard shortcut
- Category chips with live counts
- Name, recent, most-used, and favorites-first sorting
- Account-synced favorites
- Account-synced recently opened apps
- Account-synced custom apps
- Migration of older pinned and custom-app browser data
- Reliable icon fallbacks when an image is missing
- Clear unavailable/slow/partial status labels
- Open normally or directly
- Responsive desktop, tablet, and phone layouts
- App-open activity logging in the admin Activity page
- App favorites, recents, counts, and custom shortcuts included in backups and personal-data exports
- No external package dependencies

INSTALL
-------
1. Back up your current project:
   git add .
   git commit -m "Backup before Apps upgrade"

2. Upload this ZIP beside index.js and extract it:
   unzip -o Fuzz-Control-apps-upgrade.zip

3. Open Supabase > SQL Editor.

4. Paste and run everything from:
   database-apps-upgrade.sql

5. Check the JavaScript:
   node --check index.js
   node --check static/assets/js/c1.js

6. Restart:
   npm start

7. Open /b or /apps.html and hard-refresh:
   Ctrl + Shift + R

NOTES
-----
- Favorites, recents, open counts, and custom apps still save locally if the
  account-state request cannot reach the server.
- Once the SQL is installed, the page automatically syncs them to the account.
- App launches appear in Admin > Activity with category "apps".
- No existing app JSON data is removed.
